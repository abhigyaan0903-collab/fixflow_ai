import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'FixFlow AI — Report it. Track it. Fix it.', description: 'AI-powered maintenance management for every space.', icons: { icon: '/favicon.svg' } };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="en"><body>{children}</body></html>; }
