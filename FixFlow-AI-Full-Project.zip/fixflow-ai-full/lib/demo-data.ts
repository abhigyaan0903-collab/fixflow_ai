export type IssueStatus = 'Open'|'Assigned'|'In Progress'|'Waiting'|'Resolved'|'Closed';
export type Issue = {id:string;title:string;location:string;category:string;priority:'Low'|'Medium'|'High'|'Urgent';status:IssueStatus;technician:string;created:string};
export const initialIssues: Issue[] = [
{id:'FX-1024',title:'AC not cooling',location:'Building A · Room 204',category:'HVAC',priority:'High',status:'In Progress',technician:'Raj Kumar',created:'12 min ago'},
{id:'FX-1023',title:'Water leak under sink',location:'Block B · Kitchen',category:'Plumbing',priority:'Urgent',status:'Open',technician:'Unassigned',created:'28 min ago'},
{id:'FX-1022',title:'Flickering corridor light',location:'Main Building · Floor 2',category:'Electrical',priority:'Medium',status:'Assigned',technician:'Amit Singh',created:'1 hr ago'},
{id:'FX-1021',title:'Elevator door sensor',location:'Tower 2 · Lobby',category:'Equipment',priority:'High',status:'Waiting',technician:'Suresh Patel',created:'2 hrs ago'},
{id:'FX-1020',title:'Wi-Fi access point offline',location:'Admin Office',category:'Internet/IT',priority:'Medium',status:'Open',technician:'Unassigned',created:'3 hrs ago'},
{id:'FX-1019',title:'Loose classroom desk',location:'Class 8A · Room 18',category:'Structural',priority:'Low',status:'Resolved',technician:'Manoj Singh',created:'Yesterday'},
{id:'FX-1018',title:'Generator service reminder',location:'Utility Room',category:'Equipment',priority:'Medium',status:'Resolved',technician:'Raj Kumar',created:'Yesterday'},
{id:'FX-1017',title:'Drain smells in washroom',location:'West Wing · Floor 1',category:'Plumbing',priority:'Low',status:'Open',technician:'Unassigned',created:'Yesterday'},
{id:'FX-1016',title:'Projector not starting',location:'Conference Room',category:'Electrical',priority:'Medium',status:'Assigned',technician:'Amit Singh',created:'2 days ago'},
{id:'FX-1015',title:'Paint peeling near entrance',location:'Building A · Entrance',category:'Structural',priority:'Low',status:'Closed',technician:'Manoj Singh',created:'2 days ago'},
{id:'FX-1014',title:'Refrigerator temperature high',location:'Cafeteria',category:'Equipment',priority:'High',status:'In Progress',technician:'Raj Kumar',created:'3 days ago'},
{id:'FX-1013',title:'Window latch is stuck',location:'Room 302',category:'Other',priority:'Low',status:'Open',technician:'Unassigned',created:'3 days ago'}
];
export const technicians = [
{name:'Raj Kumar',skill:'HVAC, Electrical',availability:'Available',jobs:2,done:128,rating:'4.8'},
{name:'Amit Singh',skill:'Electrical, IT',availability:'On duty',jobs:3,done:96,rating:'4.6'},
{name:'Neha Sharma',skill:'Plumbing, General',availability:'On duty',jobs:2,done:112,rating:'4.7'},
{name:'Suresh Patel',skill:'HVAC, Elevators',availability:'Available',jobs:1,done:87,rating:'4.5'},
{name:'Manoj Singh',skill:'Carpentry, General',availability:'Available',jobs:0,done:76,rating:'4.3'},
{name:'Priya Das',skill:'Cleaning, General',availability:'Available',jobs:1,done:68,rating:'4.7'},
{name:'Vikram Rao',skill:'Electrical, Generators',availability:'On leave',jobs:0,done:91,rating:'4.6'},
{name:'Arjun Mehta',skill:'Plumbing, Pumps',availability:'Available',jobs:1,done:59,rating:'4.4'}
];
export const equipment = Array.from({length:25},(_,i)=>({id:`EQ-${204+i}`,name:['AC Unit','Water Pump','Generator','Elevator','Office Computer'][i%5],location:['Building A · Room 204','Utility Room','Main Building','Tower 2','Admin Office'][i%5],status:i%9===0?'Service due':'Operational',service:['12 Dec 2026','18 Nov 2026','04 Jan 2027'][i%3]}));
