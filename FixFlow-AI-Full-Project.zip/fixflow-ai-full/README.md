# FixFlow AI — Maintenance Management MVP

A responsive Next.js + TypeScript starter inspired by the supplied FixFlow dashboard reference. It includes a multi-section interactive demo UI, sample issues, technician and equipment records, charts, issue creation/status updates/assignment, preventive-maintenance previews, notifications, settings, and an AI-suggestion demo flow.

## Run locally

Requirements: Node.js 20.9+ and npm.

```bash
npm install
npm run dev
```
Open http://localhost:3000.

## Included routes / areas

The demo uses one app shell and client-side section navigation so the main flows are easy to preview: Dashboard, Issues, Report Issue, Technicians, Equipment, Preventive Maintenance, Analytics, Notifications, Settings, AI Assistant, and issue details.

## Optional Supabase setup

1. Create a Supabase project.
2. Copy `.env.example` to `.env.local` and fill in the project URL and anon key.
3. Run `supabase/schema.sql` in the Supabase SQL Editor.
4. Configure Supabase Auth providers and implement server-side signup/login/logout flows before using with real customer data.
5. Create a private Storage bucket for issue images and add organization-scoped Storage policies before enabling uploads.

**Security note:** This starter UI is demo-first. Supabase client configuration and a tenant-oriented SQL schema are included, but real authentication, organization onboarding, server-side authorization, secure uploads, and all database CRUD connections still need to be wired and tested before production use. Do not put service-role or AI API secrets in `NEXT_PUBLIC_` variables. AI results are suggestions and require human verification.

## Deploy

### Vercel (recommended for Next.js)
1. Push this folder to a GitHub repository.
2. Import that repository at https://vercel.com/new.
3. Add the environment variables if you configured Supabase.
4. Deploy. Vercel will give you a public URL.

GitHub Pages is not recommended for this project because standard Next.js server features do not run there.
